Lab 5 Variables - README
