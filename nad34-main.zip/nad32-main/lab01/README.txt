Lab 1 Administering NGINX for Web Services
