# enable debugging
set -x
PS4='+$(date +"%T.%3N"): '

# update nginx host for the specific lab
# NOTHING specific for this lab startup just files from common-tasks.sh
