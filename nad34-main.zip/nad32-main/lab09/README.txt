Lab 9 Map Variables README
