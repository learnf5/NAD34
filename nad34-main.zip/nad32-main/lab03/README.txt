Lab 3 Server Selection README
